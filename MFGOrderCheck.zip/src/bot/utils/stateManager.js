export const initializeState = () => ({
    readyForFiles: false,
    currentDir: "",
    filesToProcess: [],
    statusMessage: null,
});
